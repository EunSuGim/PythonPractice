from selenium import webdriver
from bs4 import BeautifulSoup
from pprint import pprint
import os
from urllib.parse import urlparse
import requests
import time

dr = webdriver.Chrome('C:/etc/chromedriver.exe')
dr.get("https://www.starbucks.co.kr/menu/drink_list.do")

html_source = dr.page_source

soup = BeautifulSoup(html_source,'html.parser')

products = soup.select('.product_list dd a')

prod_cd = [[product['prod'], product.find('img')['alt']] for product in products]


# pprint(products)

result = []

for prod in prod_cd:
    container = dict()
    cd = prod[0]
    name = prod[1]
    dr.get('https://www.starbucks.co.kr/menu/drink_view.do?product_cd={prod_cd}'.format(prod_cd=cd))
    html_source = dr.page_source
    soup = BeautifulSoup(html_source,'html.parser')

    volume = soup.select_one('.product_info_head #product_info01').get_text()

    #제품정보
    kcal = soup.select_one('.product_info_content .kcal dd').get_text()
    sat_FAT = soup.select_one('.product_info_content .sat_FAT dd').get_text()
    protein = soup.select_one('.product_info_content .protein dd').get_text()
    fat = soup.select_one('.product_info_content .fat dd').get_text()
    trans_FAT = soup.select_one('.product_info_content .trans_FAT dd').get_text()
    protein = soup.select_one('.product_info_content .protein dd').get_text()
    sodium = soup.select_one('.product_info_content .sodium dd').get_text()
    sugars = soup.select_one('.product_info_content .sugars dd').get_text()
    caffeine = soup.select_one('.product_info_content .caffeine dd').get_text()
    cholesterol = soup.select_one('.product_info_content .cholesterol dd').get_text()
    chabo = soup.select_one('.product_info_content .chabo dd').get_text()

    container['cd'] = cd
    container['name'] = name
    container['kcal'] = kcal
    container['sat_FAT'] = sat_FAT
    container['protein'] = protein
    container['fat'] = fat
    container['trans_FAT'] = trans_FAT
    container['protein'] = protein
    container['sodium'] = sodium
    container['sugars'] = sugars
    container['caffeine'] = caffeine
    container['cholesterol'] = cholesterol
    container['chabo'] = chabo
    result.append(container)
    # 트래픽 조절을 위해 3초간 pause time.sleep(3)
    time.sleep(2)

import pandas as pd
df = pd.DataFrame(result)
df.to_csv('./starbucks.csv', index=False)

df

pprint(result)