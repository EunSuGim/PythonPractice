from selenium import webdriver
from bs4 import BeautifulSoup
from pprint import pprint
import os
from urllib.parse import urlparse
import requests
import time

dr = webdriver.Chrome('C:/etc/chromedriver.exe')
dr.get("https://www.starbucks.co.kr/menu/drink_list.do")

html_source = dr.page_source

soup = BeautifulSoup(html_source,'html.parser')

products = soup.select('.product_list dd a')

prod_cd = [[product['prod'], product.find('img')['alt']] for product in products]


for prod in prod_cd:
    container = dict()
    cd = prod[0]
    name = prod[1]
    dr.get('https://www.starbucks.co.kr/menu/drink_view.do?product_cd={prod_cd}'.format(prod_cd=cd))
    html_source = dr.page_source
    soup = BeautifulSoup(html_source,'html.parser')

    volume = soup.select_one('.product_info_head #product_info01').get_text()
    img = soup.find('img')

    print(img['alt'])
    print(img['src'])
